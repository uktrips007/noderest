var Router = require('restify-router').Router;
var routerInstance = new  Router();
var restify = require('restify');
 
function respond(req, res, next) {
  res.send('hello ' + req.params.name);
  next();
}
 
// add a route like you would on a restify server instance
routerInstance.get('/hello/:name', respond);
 
var server = restify.createServer();
// add all routes registered in the router to this server instance
routerInstance.applyRoutes(server);
 
server.listen(8080, function() {
  console.log('%s listening at %s', server.name, server.url);
});
