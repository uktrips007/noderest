const db  = require('../db.js');
var data = {
	getResult : function(object, req,res){

			db.selectQuery(object,function(err,result){
      		if (err) {
            	// error handling code goes here
            	console.log("ERROR : ",err);            
        	} 
      		else{
      			res.end(JSON.stringify(result));
		      //:res.end("json running");
		    }
      }); 
	}
}

exports.getUser = async function(req , res) {
      var object = {
      	"fields" : "*",
      	"table" : "users",
      	"where" : "",
      	"limit" : "",
      	"order" : "id asc"
      };
      data.getResult(object, req,res);//res.end("json running");
}
exports.getUserById = async function (req , res) {
	var object = {
      	"fields" : "*",
      	"table" : "users",
      	"where" : "id=?",
      	"limit" : "",
      	"order" : "id asc",
      	"params": req.params.id
      };
      data.getResult(object, req,res);
 }

 