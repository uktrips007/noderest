const config  = require('./config');
mysql      = require('mysql');
var connection = config.db.get;

exports.selectQuery = function(object,callback) {
	  var dataSet = [];
	  var query = '';
	  if(!object.fields){
	  		object.fields = "*";
	  }
	  if(!object.table){
	  	 callback("table name is mendatory",null);
	  }
	  else{
	  	query += 'select '+object.fields+' from '+object.table;
	  }
	  if(object.where){
	  	query += ' Where '+object.where;
	  }
	  else{
	  	object.params = ''
	  }
	  if(object.order){
	  	query += ' order by '+object.order;
	  }
	  if(object.limit){
	  	query += ' limit '+object.limit;
	  }
	  console.log(query);
	  connection.query(query,[object.params], function (error, results) {
		    if (error)  return callback(error,null);
		    if(results.length){
		    	for(var i = 0; i<results.length; i++ ){     
		                    dataSet.push(results[i]);
		        }
		    }
		   callback(null, dataSet);
      		//:res.end("json running");
     });
}