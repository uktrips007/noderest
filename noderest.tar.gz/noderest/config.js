'use strict'

var mysql = require('mysql');

module.exports = {
    name: 'rest-api',
    hostname : 'http://52.77.109.147',
    version: '0.0.1',
    env: process.env.NODE_ENV || 'development',
    port: process.env.PORT || 3000,
    db: {
        get : mysql.createConnection({
			host     : '52.77.109.147',
			user     : 'max_digi_live',
			password : 'M@x_d1g1t',
			database : 'marriager'
		})
    }
}