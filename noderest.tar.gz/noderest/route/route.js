User = require('../controller/user.js');
var Router = require('restify-router').Router;
routeInstance = new  Router();
module.exports = {
	Route : function(server){
	routeInstance.applyRoutes(server);
	}
}
//rest api to get all results
routeInstance.get('/users', User.getUser);

//rest api to get a single employee data
routeInstance.get('/users/:id',User.getUserById);
 